# CSCI585-DB (HW3 - Geospatial data handling)

### Submitted By: Ruchit Bhardwaj
### USC ID: 1111-4177-99